
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateSmartCaptions = async (videoDescription: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate viral TikTok-style captions for a video about: ${videoDescription}. Return JSON array of {time, text} objects.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              time: { type: Type.NUMBER, description: "Timestamp in seconds" },
              text: { type: Type.STRING, description: "Caption text" }
            },
            required: ["time", "text"]
          }
        }
      }
    });
    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Caption generation failed:", error);
    return [];
  }
};
