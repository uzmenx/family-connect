
export type MediaType = 'video' | 'image' | 'audio' | 'text' | 'sticker' | 'voiceover';

export interface Keyframe {
  time: number;
  scale: number;
  rotation: number;
  opacity: number;
  position: { x: number; y: number };
}

export interface AudioSettings {
  volume: number;
  fadeIn: number;
  fadeOut: number;
  isMuted: boolean;
  isSolo: boolean;
  isLoop: boolean;
  autoDuck: boolean;
}

export interface MediaClip {
  id: string;
  type: MediaType;
  name: string;
  url: string;
  startTime: number;
  duration: number;
  trimStart: number;
  sourceDuration: number;
  trackIndex: number; 
  scale: number;
  rotation: number;
  opacity: number;
  position: { x: number; y: number };
  filters: {
    brightness: number;
    contrast: number;
    saturate: number;
    sepia: number;
    blur: number;
    grayscale: number;
    hueRotate: number;
    smoothSkin: number;
  };
  speed: number;
  keyframes: Keyframe[];
  audio: AudioSettings;
  thumbnails?: string[];
}

export interface Track {
  id: string;
  type: MediaType | 'mixed';
  name: string;
  isLocked: boolean;
  isVisible: boolean;
  index: number;
  height: number;
}

export interface EditorState {
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  selectedClipId: string | null;
  clips: MediaClip[];
  tracks: Track[];
  zoomLevel: number;
  isMixerOpen: boolean;
  canvasRatio: string;
  canvasSize: { width: number; height: number };
  snapEnabled: boolean;
}
