
import React from 'react';
import { 
  Plus, Type, Music, Palette, Image as ImageIcon, Frame, Mic, Volume2
} from 'lucide-react';
import { MediaType } from '../types';

interface ToolbarProps {
  activeTab: any;
  setActiveTab: (tab: any) => void;
  onAdd: (type: MediaType) => void;
  onAddText: () => void;
  onSplit: () => void;
  selectedClip: any;
}

const Toolbar: React.FC<ToolbarProps> = ({ 
  onAdd, onAddText, setActiveTab, activeTab, selectedClip
}) => {
  return (
    <div className="shrink-0 flex flex-col bg-zinc-950 border-t border-white/5 pb-4 z-50">
      <div className="h-16 flex items-center px-2 gap-1 overflow-x-auto no-scrollbar">
        <MainTab icon={<Plus size={20} className="text-blue-500" />} label="VIDEO" onClick={() => onAdd('video')} />
        <MainTab icon={<Music size={20} />} label="MUSIQA" onClick={() => onAdd('audio')} />
        <MainTab icon={<Type size={20} />} label="MATN" onClick={onAddText} />
        <MainTab icon={<Mic size={20} />} label="VOICE" onClick={() => onAdd('voiceover')} />
        
        <div className="w-px h-8 bg-white/10 mx-1 shrink-0" />

        <MainTab 
            icon={<Volume2 size={20} />} 
            label="OVOZ" 
            active={activeTab === 'audio'}
            onClick={() => setActiveTab('audio')} 
        />
        <MainTab 
            icon={<Palette size={20} />} 
            label="FILTR" 
            active={activeTab === 'filters'}
            onClick={() => setActiveTab('filters')} 
        />
        <MainTab 
            icon={<Frame size={20} />} 
            label="KADR" 
            active={activeTab === 'format'}
            onClick={() => setActiveTab('format')} 
        />
      </div>
    </div>
  );
};

const MainTab = ({ icon, label, onClick, active }: any) => (
    <button onClick={onClick} className={`flex flex-col items-center gap-1.5 py-2 px-4 min-w-[64px] transition-all active:scale-95 group shrink-0 ${active ? 'text-blue-500' : 'text-zinc-500 hover:text-zinc-300'}`}>
        <div className={`transition-all duration-300 ${active ? 'text-blue-500 drop-shadow-[0_0_8px_rgba(59,130,246,0.5)] scale-110' : 'group-hover:scale-110'}`}>{icon}</div>
        <span className="text-[9px] font-black tracking-widest uppercase leading-none opacity-90">{label}</span>
    </button>
);

export default Toolbar;
