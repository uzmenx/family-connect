
import React from 'react';
import { X, Volume2, VolumeX, Mic, Music, Headphones, Zap } from 'lucide-react';
import { EditorState, MediaClip } from '../types';

interface MixerPanelProps {
  state: EditorState;
  onClose: () => void;
  updateClip: (id: string, updates: Partial<MediaClip>) => void;
}

const MixerPanel: React.FC<MixerPanelProps> = ({ state, onClose, updateClip }) => {
  const audioClips = state.clips.filter(c => c.type === 'audio' || c.type === 'voiceover' || c.type === 'video');

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-xl flex flex-col pt-safe animate-in fade-in duration-300">
      <header className="flex items-center justify-between p-6 border-b border-white/5">
        <div className="flex items-center gap-3">
          <Headphones className="text-blue-500" size={24} />
          <h2 className="text-xl font-black uppercase tracking-widest italic">Audio Mixer Pro</h2>
        </div>
        <button onClick={onClose} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors">
          <X size={24} />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-8 no-scrollbar">
        <div className="bg-[#111] p-6 rounded-3xl border border-white/5 flex flex-col gap-4">
           <div className="flex justify-between items-center text-[10px] font-black text-zinc-500 tracking-widest uppercase">
              <span>Master Output</span>
              <span className="text-blue-400">0.0 dB</span>
           </div>
           <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 w-[70%]" />
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {audioClips.map(clip => (
            <div key={clip.id} className="bg-zinc-900/50 p-6 rounded-3xl border border-white/5 flex flex-col gap-5">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${clip.type === 'voiceover' ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>
                    {clip.type === 'voiceover' ? <Mic size={18} /> : <Music size={18} />}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-tighter">{clip.name}</h3>
                    <span className="text-[9px] text-zinc-500 font-mono italic">CH-0{clip.trackIndex + 1}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => updateClip(clip.id, { audio: { ...clip.audio, isMuted: !clip.audio.isMuted } })}
                    className={`p-2 rounded-lg text-[10px] font-black uppercase transition-colors ${clip.audio.isMuted ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-500'}`}
                  >
                    Mute
                  </button>
                  <button className="p-2 bg-zinc-800 text-zinc-500 rounded-lg text-[10px] font-black uppercase">Solo</button>
                </div>
              </div>

              <div className="flex items-center gap-4">
                 <VolumeX size={16} className="text-zinc-600" />
                 <input 
                   type="range" min="0" max="1" step="0.01" 
                   value={clip.audio.volume}
                   onChange={(e) => updateClip(clip.id, { audio: { ...clip.audio, volume: parseFloat(e.target.value) } })}
                   className="flex-1 accent-blue-500 h-1.5 bg-zinc-800 rounded-full appearance-none cursor-pointer"
                 />
                 <Volume2 size={16} className="text-zinc-400" />
                 <span className="w-10 text-right text-[10px] font-mono text-blue-400">{(clip.audio.volume * 100).toFixed(0)}%</span>
              </div>

              {clip.type === 'voiceover' && (
                <div className="flex items-center justify-between bg-black/40 p-3 rounded-xl border border-white/5">
                  <div className="flex items-center gap-2">
                    <Zap size={14} className="text-yellow-400" />
                    <span className="text-[9px] font-bold uppercase tracking-widest text-zinc-400">Auto-Ducking</span>
                  </div>
                  <input 
                    type="checkbox" 
                    checked={clip.audio.autoDuck}
                    onChange={(e) => updateClip(clip.id, { audio: { ...clip.audio, autoDuck: e.target.checked } })}
                    className="w-4 h-4 accent-yellow-400"
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <footer className="p-8 border-t border-white/5 flex justify-center">
         <button onClick={onClose} className="px-10 py-3 bg-white text-black rounded-full font-black uppercase tracking-[0.2em] text-xs shadow-2xl active:scale-95 transition-transform">
            Saqlash va Chiqish
         </button>
      </footer>
    </div>
  );
};

export default MixerPanel;
