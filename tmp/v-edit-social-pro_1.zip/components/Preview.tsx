
import React, { useMemo, useState, useRef, useEffect } from 'react';
import { EditorState, MediaClip } from '../types';
import { Zap, RotateCw } from 'lucide-react';

interface PreviewProps {
  state: EditorState;
  setState: React.Dispatch<React.SetStateAction<EditorState>>;
  updateClip: (id: string, updates: Partial<MediaClip>) => void;
}

// VIDEO COMPONENT
const VideoElement = React.memo(({ clip, currentTime, isPlaying }: { clip: MediaClip, currentTime: number, isPlaying: boolean }) => {
    const videoRef = useRef<HTMLVideoElement>(null);

    useEffect(() => {
        const el = videoRef.current;
        if (!el) return;

        const offset = currentTime - clip.startTime;
        const clipDurationInTimeline = clip.duration / clip.speed;

        el.playbackRate = clip.speed;
        el.volume = clip.audio.isMuted ? 0 : clip.audio.volume;

        if (offset >= 0 && offset <= clipDurationInTimeline) {
            const targetVideoTime = clip.trimStart + (offset * clip.speed);
            
            if (isPlaying) {
                if (el.paused) {
                    el.currentTime = targetVideoTime;
                    el.play().catch(() => {});
                } else {
                    if (Math.abs(el.currentTime - targetVideoTime) > 0.25) {
                        el.currentTime = targetVideoTime;
                    }
                }
            } else {
                el.pause();
                if (Math.abs(el.currentTime - targetVideoTime) > 0.05) {
                    el.currentTime = targetVideoTime;
                }
            }
        } else {
            el.pause();
        }
    }, [currentTime, isPlaying, clip.id, clip.speed, clip.trimStart, clip.startTime, clip.duration, clip.audio.isMuted, clip.audio.volume]);

    return <video ref={videoRef} src={clip.url} className="w-full h-full object-cover pointer-events-none" muted={clip.audio.isMuted} playsInline />;
});

// AUDIO COMPONENT
const AudioElement = React.memo(({ clip, currentTime, isPlaying }: { clip: MediaClip, currentTime: number, isPlaying: boolean }) => {
    const audioRef = useRef<HTMLAudioElement>(null);
    useEffect(() => {
        const el = audioRef.current;
        if (!el) return;
        const offset = currentTime - clip.startTime;
        const clipDurationInTimeline = clip.duration / clip.speed;
        el.playbackRate = clip.speed;
        let volume = clip.audio.isMuted ? 0 : clip.audio.volume;
        if (!clip.audio.isMuted) {
            if (offset < clip.audio.fadeIn) volume = volume * (offset / clip.audio.fadeIn);
            else if (offset > clipDurationInTimeline - clip.audio.fadeOut) {
                const fadeOutProgress = (clipDurationInTimeline - offset) / clip.audio.fadeOut;
                volume = volume * Math.max(0, fadeOutProgress);
            }
        }
        el.volume = Math.max(0, Math.min(1, volume));
        if (offset >= 0 && offset <= clipDurationInTimeline) {
            const targetTime = clip.trimStart + (offset * clip.speed);
            if (isPlaying) {
                if (el.paused) { el.currentTime = targetTime; el.play().catch(() => {}); } 
                else { if (Math.abs(el.currentTime - targetTime) > 0.25) el.currentTime = targetTime; }
            } else { el.pause(); if (Math.abs(el.currentTime - targetTime) > 0.05) el.currentTime = targetTime; }
        } else { el.pause(); }
    }, [currentTime, isPlaying, clip.id, clip.speed, clip.trimStart, clip.startTime, clip.duration, clip.audio]);
    return <audio ref={audioRef} src={clip.url} />;
});

// --- HELPER MATH FUNCTIONS FOR GESTURES ---
const getDistance = (touches: React.TouchList) => {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
};

const getAngle = (touches: React.TouchList) => {
    const dx = touches[1].clientX - touches[0].clientX;
    const dy = touches[1].clientY - touches[0].clientY;
    return Math.atan2(dy, dx) * (180 / Math.PI);
};

const Preview: React.FC<PreviewProps> = ({ state, setState, updateClip }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Interaction State
  const [gesture, setGesture] = useState<{ 
      id: string;
      mode: 'drag' | 'scale-rotate';
      startX: number;
      startY: number;
      startPos: { x: number, y: number };
      startScale: number;
      startRotation: number;
      startDistance?: number;
      startAngle?: number;
  } | null>(null);

  const getZIndex = (trackIndex: number) => {
      if (trackIndex <= 1) return 50; // Text
      if (trackIndex === 2) return 40; // Overlay
      if (trackIndex === 3) return 10; // Main
      return 0; // Audio
  };

  const visibleClips = useMemo(() => {
      return state.clips.filter(c => 
          state.currentTime >= c.startTime && 
          state.currentTime < c.startTime + (c.duration / c.speed)
      ).sort((a, b) => getZIndex(a.trackIndex) - getZIndex(b.trackIndex));
  }, [state.clips, state.currentTime]);

  // --- TOUCH HANDLERS ---
  const handleTouchStart = (e: React.TouchEvent) => {
      const target = e.target as HTMLElement;
      // Find the clip ID from the DOM element attribute
      const clipId = target.closest('[data-clip-id]')?.getAttribute('data-clip-id');
      
      if (!clipId) return;
      
      const clip = state.clips.find(c => c.id === clipId);
      if (!clip || clip.trackIndex === 3 || clip.type === 'audio' || clip.type === 'voiceover') return;

      e.stopPropagation();
      setState(p => ({ ...p, selectedClipId: clipId }));

      if (e.touches.length === 2) {
          // MULTI TOUCH: Scale & Rotate
          setGesture({
              id: clipId,
              mode: 'scale-rotate',
              startX: 0, startY: 0, // Not used for pinch
              startPos: { ...clip.position },
              startScale: clip.scale,
              startRotation: clip.rotation,
              startDistance: getDistance(e.touches),
              startAngle: getAngle(e.touches)
          });
      } else {
          // SINGLE TOUCH: Drag
          setGesture({
              id: clipId,
              mode: 'drag',
              startX: e.touches[0].clientX,
              startY: e.touches[0].clientY,
              startPos: { ...clip.position },
              startScale: clip.scale,
              startRotation: clip.rotation
          });
      }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
      if (!gesture) return;
      e.preventDefault();

      const clip = state.clips.find(c => c.id === gesture.id);
      if (!clip) return;

      if (gesture.mode === 'scale-rotate' && e.touches.length === 2 && gesture.startDistance && gesture.startAngle !== undefined) {
          // Handle Pinch/Zoom & Rotate
          const newDist = getDistance(e.touches);
          const newAngle = getAngle(e.touches);
          
          const scaleMultiplier = newDist / gesture.startDistance;
          const rotationDelta = newAngle - gesture.startAngle;

          updateClip(gesture.id, {
              scale: Math.max(0.2, Math.min(5, gesture.startScale * scaleMultiplier)),
              rotation: gesture.startRotation + rotationDelta
          });
      } else if (gesture.mode === 'drag' && e.touches.length === 1) {
          // Handle Drag
          const dx = e.touches[0].clientX - gesture.startX;
          const dy = e.touches[0].clientY - gesture.startY;
          updateClip(gesture.id, {
              position: {
                  x: gesture.startPos.x + dx,
                  y: gesture.startPos.y + dy
              }
          });
      }
  };

  // MOUSE HANDLERS (Fallback for desktop testing)
  const handleMouseDown = (e: React.MouseEvent, clip: MediaClip) => {
      if (clip.trackIndex === 3 || clip.type === 'audio' || clip.type === 'voiceover') return; 
      e.stopPropagation();
      setState(p => ({...p, selectedClipId: clip.id}));
      setGesture({
          id: clip.id,
          mode: 'drag',
          startX: e.clientX,
          startY: e.clientY,
          startPos: { ...clip.position },
          startScale: clip.scale,
          startRotation: clip.rotation
      });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
      if (!gesture || gesture.mode !== 'drag') return;
      const dx = e.clientX - gesture.startX;
      const dy = e.clientY - gesture.startY;
      updateClip(gesture.id, {
          position: {
              x: gesture.startPos.x + dx,
              y: gesture.startPos.y + dy
          }
      });
  };

  const handleEnd = () => setGesture(null);

  const canvasStyle = useMemo(() => {
      const ratios: Record<string, number> = { '9:16': 9/16, '16:9': 16/9, '1:1': 1, '4:5': 4/5 };
      const ratio = ratios[state.canvasRatio] || 9/16;
      let width = 100;
      let height = 100;
      if (ratio < 1) { height = 100; width = height * ratio; } 
      else { width = 100; height = width / ratio; }
      return { width: `${width}%`, height: `${height}%`, aspectRatio: `${ratio}` };
  }, [state.canvasRatio]);

  return (
    <div 
        className="w-full h-full flex items-center justify-center relative touch-none bg-[#050505]"
        onMouseMove={handleMouseMove}
        onMouseUp={handleEnd}
        onMouseLeave={handleEnd}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleEnd}
        onTouchCancel={handleEnd}
    >
        <div 
            ref={containerRef}
            style={canvasStyle}
            className="bg-black relative shadow-2xl overflow-hidden ring-1 ring-white/10"
        >
            {visibleClips.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center text-zinc-700">
                    <Zap size={48} className="opacity-20" />
                </div>
            )}

            {visibleClips.map(clip => {
                const zIndex = getZIndex(clip.trackIndex);
                const isSelected = state.selectedClipId === clip.id;
                const isOverlay = clip.trackIndex !== 3 && clip.type !== 'audio' && clip.type !== 'voiceover';
                
                if (clip.type === 'audio' || clip.type === 'voiceover') {
                    return <AudioElement key={clip.id} clip={clip} currentTime={state.currentTime} isPlaying={state.isPlaying} />;
                }

                return (
                    <div 
                        key={clip.id}
                        data-clip-id={clip.id}
                        onMouseDown={(e) => handleMouseDown(e, clip)}
                        onTouchStart={handleTouchStart}
                        className={`absolute flex items-center justify-center origin-center touch-none
                            ${isSelected && isOverlay ? 'ring-2 ring-blue-500 cursor-move' : ''}
                        `}
                        style={{
                            zIndex: zIndex,
                            transform: `translate(${clip.position.x}px, ${clip.position.y}px) rotate(${clip.rotation}deg) scale(${clip.scale})`,
                            width: clip.type === 'video' && clip.trackIndex === 3 ? '100%' : 'auto',
                            height: clip.type === 'video' && clip.trackIndex === 3 ? '100%' : 'auto',
                            opacity: clip.opacity,
                            filter: `brightness(${clip.filters.brightness}) contrast(${clip.filters.contrast}) saturate(${clip.filters.saturate}) sepia(${clip.filters.sepia}%) grayscale(${clip.filters.grayscale}%) blur(${clip.filters.blur}px)`
                        }}
                    >
                        {clip.type === 'video' && <VideoElement clip={clip} currentTime={state.currentTime} isPlaying={state.isPlaying} />}
                        
                        {clip.type === 'image' && (
                            <img src={clip.url} className="max-w-[200px] object-contain pointer-events-none" />
                        )}
                        
                        {clip.type === 'text' && (
                            <div className="text-white text-3xl font-black uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] whitespace-nowrap px-4 py-2">
                                {clip.url}
                            </div>
                        )}

                        {clip.type === 'sticker' && (
                             <img src={clip.url} className="w-32 h-32 object-contain pointer-events-none" />
                        )}

                        {isSelected && isOverlay && (
                             <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                                 <RotateCw size={10} className="text-black" />
                             </div>
                        )}
                    </div>
                );
            })}
        </div>
    </div>
  );
};

export default Preview;
