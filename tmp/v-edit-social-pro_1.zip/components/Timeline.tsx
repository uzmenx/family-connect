
import React, { useRef, useState, useEffect, useCallback, memo } from 'react';
import { EditorState, MediaClip, Track } from '../types';
import { Music, Type, Image as ImageIcon, Video, Mic, Eye, Lock } from 'lucide-react';

interface TimelineProps {
  state: EditorState;
  setState: React.Dispatch<React.SetStateAction<EditorState>>;
  updateClip: (id: string, updates: Partial<MediaClip>) => void;
}

// --- 1. MEMOIZED RULER ---
const TimeRuler = memo(({ duration, zoomLevel }: { duration: number, zoomLevel: number }) => {
    const ticks = Array.from({ length: Math.ceil(duration) + 5 });
    return (
        <div className="h-8 border-b border-white/10 relative w-full pointer-events-none">
            {ticks.map((_, i) => (
                <div key={i} className="absolute bottom-0 h-full flex flex-col justify-end" style={{ left: i * zoomLevel }}>
                    <div className="h-1.5 w-px bg-zinc-700" />
                    <span className="text-[8px] font-mono text-zinc-600 -ml-1 mb-2 select-none">{i}s</span>
                    {Array.from({length: 4}).map((_, j) => (
                        <div key={j} className="absolute bottom-0 h-1 w-px bg-zinc-800" style={{ left: (j+1) * (zoomLevel/5) }} />
                    ))}
                </div>
            ))}
        </div>
    );
});

// --- 2. MEMOIZED CLIP ITEM ---
const TimelineClipItem = memo(({ clip, zoomLevel, isSelected, trackType, onDown }: { 
    clip: MediaClip, zoomLevel: number, isSelected: boolean, trackType: string, onDown: (e: React.PointerEvent, type: 'move'|'trimStart'|'trimEnd') => void 
}) => {
    const width = (clip.duration / clip.speed) * zoomLevel;
    const left = clip.startTime * zoomLevel;

    return (
        <div 
            onPointerDown={(e) => onDown(e, 'move')}
            style={{ left, width }}
            className={`absolute top-1 bottom-1 rounded-md overflow-hidden border flex items-center group touch-none select-none
                ${isSelected ? 'border-white bg-blue-500/30 z-10 shadow-lg' : 'border-white/10 bg-zinc-800/80 hover:bg-zinc-700'}
                ${trackType === 'video' ? 'bg-blue-900/20' : trackType === 'audio' ? 'bg-green-900/20' : 'bg-purple-900/20'}
            `}
        >
            <div className="flex-1 flex items-center gap-2 px-2 overflow-hidden pointer-events-none">
                {trackType === 'video' && <div className="w-8 h-full bg-white/10 rounded-sm" />}
                <span className="text-[9px] font-bold truncate opacity-80">{clip.name}</span>
            </div>

            {isSelected && (
                <>
                    <div className="absolute left-0 w-4 h-full cursor-w-resize bg-gradient-to-r from-white/20 to-transparent hover:from-white/40 z-20" onPointerDown={(e) => onDown(e, 'trimStart')} />
                    <div className="absolute right-0 w-4 h-full cursor-e-resize bg-gradient-to-l from-white/20 to-transparent hover:from-white/40 z-20" onPointerDown={(e) => onDown(e, 'trimEnd')} />
                </>
            )}
        </div>
    );
}, (prev, next) => {
    return prev.clip.id === next.clip.id &&
           prev.clip.startTime === next.clip.startTime &&
           prev.clip.duration === next.clip.duration &&
           prev.clip.trackIndex === next.clip.trackIndex &&
           prev.zoomLevel === next.zoomLevel &&
           prev.isSelected === next.isSelected;
});

// --- 3. MEMOIZED TRACK ROW ---
const TrackRow = memo(({ track, clips, zoomLevel, selectedClipId, onClipDown }: {
    track: Track, clips: MediaClip[], zoomLevel: number, selectedClipId: string | null, onClipDown: (e: any, clip: any, type: any) => void
}) => {
    return (
        <div style={{height: track.height}} className="border-b border-white/5 relative w-full bg-[#050505]">
            <div className="absolute inset-0 opacity-5 bg-[linear-gradient(90deg,transparent_49%,#fff_50%,transparent_51%)] bg-[length:100px_100px] pointer-events-none" />
            {clips.map(clip => (
                <TimelineClipItem 
                    key={clip.id}
                    clip={clip}
                    zoomLevel={zoomLevel}
                    trackType={track.type}
                    isSelected={selectedClipId === clip.id}
                    onDown={(e, type) => onClipDown(e, clip, type)}
                />
            ))}
        </div>
    );
});

const Timeline: React.FC<TimelineProps> = ({ state, setState, updateClip }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const isScrollingRef = useRef(false);
  const [dragState, setDragState] = useState<{ 
      id: string, 
      type: 'move' | 'trimStart' | 'trimEnd', 
      startX: number, 
      startMsgTime: number, 
      startDuration: number, 
      startTrim: number 
  } | null>(null);

  // Sync Player -> Scroll
  useEffect(() => {
    if (scrollRef.current && !isScrollingRef.current && !dragState) {
       const targetScroll = state.currentTime * state.zoomLevel;
       const currentScroll = scrollRef.current.scrollLeft;
       if (Math.abs(targetScroll - currentScroll) > 5) {
           scrollRef.current.scrollLeft = targetScroll;
       }
    }
  }, [state.currentTime, state.zoomLevel, dragState]);

  // Sync Scroll -> Player
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
      if (state.isPlaying) return;
      isScrollingRef.current = true;
      const scrollLeft = e.currentTarget.scrollLeft;
      const newTime = scrollLeft / state.zoomLevel;
      setState(prev => ({ ...prev, currentTime: Math.max(0, Math.min(prev.duration, newTime)) }));
      clearTimeout((window as any).scrollTimeout);
      (window as any).scrollTimeout = setTimeout(() => { isScrollingRef.current = false; }, 100);
  }, [state.zoomLevel, state.isPlaying]);

  // Drag Logic
  const handlePointerDown = useCallback((e: React.PointerEvent, clip: MediaClip, type: 'move' | 'trimStart' | 'trimEnd') => {
      e.stopPropagation();
      if (clip.trackIndex === 3 && type === 'move') return; 
      setDragState({
          id: clip.id, type, startX: e.clientX,
          startMsgTime: clip.startTime, startDuration: clip.duration, startTrim: clip.trimStart
      });
      setState(p => ({...p, selectedClipId: clip.id}));
  }, []);

  useEffect(() => {
      if (!dragState) return;
      const onMove = (e: PointerEvent) => {
          e.preventDefault();
          const deltaPixels = e.clientX - dragState.startX;
          const deltaTime = deltaPixels / state.zoomLevel;

          if (dragState.type === 'move') {
              updateClip(dragState.id, { startTime: Math.max(0, dragState.startMsgTime + deltaTime) });
          } 
          else if (dragState.type === 'trimStart') {
              let newStart = dragState.startMsgTime + deltaTime;
              let cutAmount = deltaTime; 
              if (newStart < 0) { newStart = 0; cutAmount = -dragState.startMsgTime; }
              const newDuration = dragState.startDuration - cutAmount;
              if (newDuration > 0.5) {
                 updateClip(dragState.id, { 
                     startTime: newStart, 
                     duration: newDuration, 
                     trimStart: dragState.startTrim + (cutAmount * 1) 
                 });
              }
          } 
          else if (dragState.type === 'trimEnd') {
              const newDuration = Math.max(0.5, dragState.startDuration + deltaTime);
              updateClip(dragState.id, { duration: newDuration });
          }
      };
      const onUp = () => setDragState(null);
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      return () => {
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onUp);
      };
  }, [dragState, state.zoomLevel]);

  const contentWidth = Math.max(window.innerWidth, (state.duration * state.zoomLevel) + window.innerWidth);

  return (
    <div className="flex h-full select-none text-white">
        <div className="w-16 bg-[#111] border-r border-white/10 flex flex-col pt-8 z-20 shadow-xl shrink-0">
            {state.tracks.map(track => (
                <div key={track.id} style={{height: track.height}} className="flex flex-col items-center justify-center border-b border-white/5 relative group">
                    <div className="text-zinc-500 group-hover:text-white transition-colors">
                        {track.type === 'text' && <Type size={14} />}
                        {track.type === 'video' && <Video size={14} />}
                        {track.type === 'audio' && <Music size={14} />}
                        {track.type === 'mixed' && <ImageIcon size={14} />}
                        {track.type === 'voiceover' && <Mic size={14} />}
                    </div>
                </div>
            ))}
        </div>
        <div className="flex-1 relative overflow-hidden bg-[#050505]">
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-red-500 z-50 pointer-events-none shadow-[0_0_8px_rgba(255,0,0,0.8)]">
                <div className="absolute -top-0 -left-[5px] w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-red-500" />
            </div>
            <div 
                ref={scrollRef}
                className="h-full overflow-x-auto overflow-y-hidden no-scrollbar relative will-change-scroll"
                onScroll={handleScroll}
            >
                <div className="relative h-full" style={{ width: contentWidth, paddingLeft: '50%', paddingRight: '50%' }}>
                    <TimeRuler duration={state.duration} zoomLevel={state.zoomLevel} />
                    <div className="pt-0">
                        {state.tracks.map(track => (
                            <TrackRow 
                                key={track.id}
                                track={track}
                                clips={state.clips.filter(c => c.trackIndex === track.index)}
                                zoomLevel={state.zoomLevel}
                                selectedClipId={state.selectedClipId}
                                onClipDown={handlePointerDown}
                            />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Timeline;
