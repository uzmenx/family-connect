
import React, { useState } from 'react';
import { X, Search, Video, Image as ImageIcon, Music, History, Play } from 'lucide-react';
import { MediaType } from '../types';

interface AssetPickerProps {
  type: MediaType;
  onSelect: (type: MediaType, url: string) => void;
  onClose: () => void;
}

const AssetPicker: React.FC<AssetPickerProps> = ({ type, onSelect, onClose }) => {
  const [activeType, setActiveType] = useState<MediaType>(type);

  const assets = {
    video: [
      'https://assets.mixkit.co/videos/preview/mixkit-curvy-road-running-through-a-forest-32886-large.mp4',
      'https://assets.mixkit.co/videos/preview/mixkit-water-flowing-between-rocks-in-a-forest-4275-large.mp4',
      'https://assets.mixkit.co/videos/preview/mixkit-stars-in-the-night-sky-above-a-desert-41409-large.mp4',
    ],
    image: [
      'https://picsum.photos/400/800?random=1',
      'https://picsum.photos/400/800?random=2',
      'https://picsum.photos/400/800?random=3',
    ],
    audio: [
      'https://assets.mixkit.co/music/preview/mixkit-driving-ambition-32.mp3',
      'https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3',
      'https://assets.mixkit.co/music/preview/mixkit-hip-hop-02-738.mp3',
      'https://assets.mixkit.co/music/preview/mixkit-dreaming-big-31.mp3'
    ]
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col pt-safe animate-in slide-in-from-bottom duration-300">
      <header className="flex items-center justify-between p-4 border-b border-white/5">
        <button onClick={onClose} className="p-2 -ml-2"><X size={24} /></button>
        <div className="flex bg-zinc-900 rounded-lg p-1">
          <button 
            onClick={() => setActiveType('video')}
            className={`px-4 py-1.5 rounded-md text-sm transition-all ${activeType === 'video' ? 'bg-zinc-700 text-white' : 'text-gray-500'}`}
          >
            Video
          </button>
          <button 
            onClick={() => setActiveType('image')}
            className={`px-4 py-1.5 rounded-md text-sm transition-all ${activeType === 'image' ? 'bg-zinc-700 text-white' : 'text-gray-500'}`}
          >
            Foto
          </button>
          <button 
            onClick={() => setActiveType('audio')}
            className={`px-4 py-1.5 rounded-md text-sm transition-all ${activeType === 'audio' ? 'bg-zinc-700 text-white' : 'text-gray-500'}`}
          >
            Musiqa
          </button>
        </div>
        <div className="w-10"></div>
      </header>

      <div className="p-4 shrink-0">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input 
            type="text" 
            placeholder="Kutubxonadan qidiring..." 
            className="w-full bg-zinc-900 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 grid grid-cols-3 gap-3">
        {activeType === 'video' && assets.video.map((url, i) => (
          <div 
            key={i} 
            onClick={() => onSelect('video', url)}
            className="aspect-[9/16] bg-zinc-800 rounded-lg overflow-hidden relative cursor-pointer group"
          >
            <video src={url} className="w-full h-full object-cover" muted />
            <div className="absolute bottom-2 right-2 text-[10px] bg-black/50 px-1 rounded">0:15</div>
            <div className="absolute inset-0 bg-blue-500/0 group-hover:bg-blue-500/20 transition-all flex items-center justify-center">
               <Video size={24} className="text-white opacity-0 group-hover:opacity-100 scale-50 group-hover:scale-100 transition-all" />
            </div>
          </div>
        ))}
        {activeType === 'image' && assets.image.map((url, i) => (
          <div 
            key={i} 
            onClick={() => onSelect('image', url)}
            className="aspect-[9/16] bg-zinc-800 rounded-lg overflow-hidden relative cursor-pointer"
          >
            <img src={url} className="w-full h-full object-cover" />
          </div>
        ))}
        {activeType === 'audio' && assets.audio.map((url, i) => (
          <div 
            key={i} 
            onClick={() => onSelect('audio', url)}
            className="col-span-3 h-16 bg-zinc-900 rounded-xl flex items-center px-4 gap-4 cursor-pointer hover:bg-zinc-800 transition-colors border border-white/5"
          >
            <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                <Music size={20} />
            </div>
            <div className="flex-1">
                <div className="text-sm font-bold text-white">Music Track {i+1}</div>
                <div className="text-[10px] text-zinc-500">3:45 • Hip Hop</div>
            </div>
            <div className="p-2 bg-white/5 rounded-full"><Play size={14} fill="white" className="ml-0.5" /></div>
          </div>
        ))}
      </div>

      <div className="p-6 bg-zinc-900/50 border-t border-white/5 flex flex-col items-center gap-4">
        <label className="w-full">
            <input type="file" className="hidden" accept={activeType === 'audio' ? 'audio/*' : activeType === 'video' ? 'video/*' : 'image/*'} onChange={(e) => {
                const file = e.target.files?.[0];
                if(file) onSelect(activeType, URL.createObjectURL(file));
            }} />
            <div className="w-full bg-white text-black py-3 rounded-xl font-semibold flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform">
                <History size={20} /> Telefonda tanlash
            </div>
        </label>
        <p className="text-[10px] text-gray-500 uppercase tracking-widest">Yoki kutubxonadan tanlang</p>
      </div>
    </div>
  );
};

export default AssetPicker;
