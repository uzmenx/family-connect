
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ChevronLeft, Copy, Trash2, Play, Pause, Scissors,
  Clock, Volume2, Palette, Frame, Layers, Undo2, Redo2, Zap, X
} from 'lucide-react';
import { MediaClip, EditorState, MediaType, Track } from './types';
import Timeline from './components/Timeline';
import Preview from './components/Preview';
import Toolbar from './components/Toolbar';
import AssetPicker from './components/AssetPicker';
import MixerPanel from './components/MixerPanel';

// Tracklar konfiguratsiyasi
const INITIAL_TRACKS: Track[] = [
  { id: 't-text-1', type: 'text', name: 'TEXT 1', index: 0, isLocked: false, isVisible: true, height: 40 },
  { id: 't-text-2', type: 'text', name: 'TEXT 2', index: 1, isLocked: false, isVisible: true, height: 40 },
  { id: 't-overlay', type: 'mixed', name: 'OVERLAY', index: 2, isLocked: false, isVisible: true, height: 60 },
  { id: 't-main', type: 'video', name: 'MAIN', index: 3, isLocked: false, isVisible: true, height: 80 },
  { id: 't-voice', type: 'voiceover', name: 'VOICE', index: 4, isLocked: false, isVisible: true, height: 40 },
  { id: 't-music', type: 'audio', name: 'MUSIC', index: 5, isLocked: false, isVisible: true, height: 40 },
];

const INITIAL_STATE: EditorState = {
  currentTime: 0,
  duration: 5, 
  isPlaying: false,
  selectedClipId: null,
  clips: [], 
  tracks: INITIAL_TRACKS,
  zoomLevel: 50,
  isMixerOpen: false,
  canvasRatio: '9:16',
  canvasSize: { width: 360, height: 640 },
  snapEnabled: true
};

const App: React.FC = () => {
  const [state, setState] = useState<EditorState>(INITIAL_STATE);
  const [showAssetPicker, setShowAssetPicker] = useState(false);
  const [pickerType, setPickerType] = useState<MediaType>('video');
  const [activeTab, setActiveTab] = useState<'speed' | 'audio' | 'format' | 'filters' | null>(null);
  const [textInput, setTextInput] = useState<{show: boolean, value: string}>({show: false, value: ''});
  const textInputRef = useRef<HTMLInputElement>(null);

  // --- IRON LOGIC: Magnit Tizimi ---
  const normalizeClips = useCallback((clips: MediaClip[]): MediaClip[] => {
    const mainTrackClips = clips.filter(c => c.trackIndex === 3).sort((a, b) => a.startTime - b.startTime);
    const otherClips = clips.filter(c => c.trackIndex !== 3);
    
    let currentPos = 0;
    const normalizedMain = mainTrackClips.map(clip => {
      const realDuration = clip.duration / clip.speed;
      const updated = { ...clip, startTime: currentPos };
      currentPos += realDuration;
      return updated;
    });

    return [...normalizedMain, ...otherClips];
  }, []);

  // Duration
  useEffect(() => {
    const totalDur = state.clips.reduce((max, clip) => {
      const end = clip.startTime + (clip.duration / clip.speed);
      return Math.max(max, end);
    }, 5);
    if (Math.abs(state.duration - totalDur) > 0.1) setState(prev => ({ ...prev, duration: totalDur }));
  }, [state.clips]);

  // Player Loop (60 FPS optimization)
  useEffect(() => {
    let rafId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      if (!state.isPlaying) return;
      
      const deltaTime = (time - lastTime) / 1000;
      lastTime = time;

      setState(prev => {
        if (!prev.isPlaying) return prev;
        
        let nextTime = prev.currentTime + deltaTime;
        if (nextTime >= prev.duration) {
          return { ...prev, currentTime: 0, isPlaying: false };
        }
        return { ...prev, currentTime: nextTime };
      });
      
      rafId = requestAnimationFrame(loop);
    };

    if (state.isPlaying) {
      lastTime = performance.now();
      rafId = requestAnimationFrame(loop);
    }

    return () => cancelAnimationFrame(rafId);
  }, [state.isPlaying]);

  const updateClip = (clipId: string, updates: Partial<MediaClip>) => {
    setState(prev => {
      const newClips = prev.clips.map(c => c.id === clipId ? { ...c, ...updates } : c);
      const needsNormalization = updates.startTime !== undefined || updates.duration !== undefined || updates.speed !== undefined;
      return { ...prev, clips: needsNormalization ? normalizeClips(newClips) : newClips };
    });
  };

  const splitClip = () => {
    const clip = state.clips.find(c => c.id === state.selectedClipId);
    if (!clip) return;
    const playhead = state.currentTime;
    const clipStart = clip.startTime;
    const clipEnd = clip.startTime + (clip.duration / clip.speed);
    if (playhead <= clipStart + 0.1 || playhead >= clipEnd - 0.1) return;

    const splitPoint = (playhead - clipStart) * clip.speed;
    const part1Dur = splitPoint;
    const part2Dur = clip.duration - splitPoint;

    const part1 = { ...clip, duration: part1Dur };
    const part2 = { ...clip, id: `split-${Date.now()}`, startTime: playhead, trimStart: clip.trimStart + part1Dur, duration: part2Dur };

    setState(prev => ({ ...prev, clips: normalizeClips([...prev.clips.filter(c => c.id !== clip.id), part1, part2]), selectedClipId: part2.id }));
  };

  const deleteClip = () => {
    if (!state.selectedClipId) return;
    setState(prev => ({ ...prev, clips: normalizeClips(prev.clips.filter(c => c.id !== prev.selectedClipId)), selectedClipId: null }));
    setActiveTab(null);
  };

  const handleAddAsset = (type: MediaType, url: string) => {
    const trackMap: Record<string, number> = { text: 0, sticker: 2, image: 2, video: 3, voiceover: 4, audio: 5 };
    const targetTrack = trackMap[type] ?? 3;
    const newClip: MediaClip = {
      id: `clip-${Date.now()}`, type, name: type.toUpperCase(), url,
      startTime: targetTrack === 3 ? 99999 : state.currentTime,
      duration: type === 'image' || type === 'text' ? 3 : (type === 'audio' ? 15 : 5), 
      trimStart: 0, sourceDuration: 30, trackIndex: targetTrack,
      scale: 1, rotation: 0, opacity: 1, position: { x: 0, y: 0 },
      filters: { brightness: 1, contrast: 1, saturate: 1, sepia: 0, blur: 0, grayscale: 0, hueRotate: 0, smoothSkin: 0 },
      speed: 1, keyframes: [],
      audio: { volume: 1, fadeIn: 0, fadeOut: 0, isMuted: false, isSolo: false, isLoop: false, autoDuck: false },
      thumbnails: [url]
    };
    setState(prev => ({ ...prev, clips: normalizeClips([...prev.clips, newClip]), selectedClipId: newClip.id }));
    setShowAssetPicker(false);
  };

  const handleAddText = () => {
     if(!textInput.value.trim()) { setTextInput({show:false, value:''}); return; }
     handleAddAsset('text', textInput.value);
     setTextInput({show:false, value:''});
  };

  const selectedClip = state.clips.find(c => c.id === state.selectedClipId);

  return (
    <div className="flex flex-col h-[100dvh] bg-black text-white select-none overflow-hidden font-inter">
      {/* HEADER */}
      <header className="shrink-0 flex items-center justify-between px-4 py-3 bg-zinc-900 border-b border-white/5 z-50">
        <div className="flex items-center gap-3">
            <button className="p-2 bg-white/5 rounded-full hover:bg-white/10"><ChevronLeft size={18} /></button>
            <h1 className="text-xs font-black tracking-[0.2em] text-zinc-400 uppercase">V-PRO STUDIO</h1>
        </div>
        <div className="flex items-center gap-3">
            <div className="flex gap-1 mr-4">
                <button className="p-2 hover:text-white text-zinc-500"><Undo2 size={16} /></button>
                <button className="p-2 hover:text-white text-zinc-500"><Redo2 size={16} /></button>
            </div>
            <button onClick={() => setState(p => ({...p, isMixerOpen: true}))} className="px-4 py-1.5 bg-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-zinc-700">Mixer</button>
            <button className="px-6 py-1.5 bg-blue-600 rounded-lg text-[10px] font-bold uppercase tracking-wider shadow-[0_0_15px_rgba(37,99,235,0.3)]">Eksport</button>
        </div>
      </header>

      {/* WORKSPACE */}
      <div className="flex-1 flex flex-col relative overflow-hidden">
         {/* PREVIEW */}
         <div className="flex-1 bg-[#050505] flex items-center justify-center relative p-4 pb-0 overflow-hidden">
             <Preview state={state} setState={setState} updateClip={updateClip} />
             
             {/* PROPERTY PANELS */}
             {activeTab && (
                 <div className="absolute bottom-0 left-0 right-0 bg-zinc-900/95 backdrop-blur-xl border-t border-white/10 p-4 z-50 animate-in slide-in-from-bottom-5">
                     <div className="flex justify-between items-center mb-4">
                         <span className="text-xs font-black uppercase text-blue-400 tracking-widest">{activeTab}</span>
                         <button onClick={() => setActiveTab(null)}><X size={16} className="text-zinc-500" /></button>
                     </div>
                     
                     {activeTab === 'speed' && selectedClip && (
                         <div className="space-y-2">
                             <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                                 <span>0.5x</span>
                                 <span className="text-white text-lg font-bold">{selectedClip.speed.toFixed(1)}x</span>
                                 <span>3.0x</span>
                             </div>
                             <input type="range" min="0.5" max="3" step="0.1" value={selectedClip.speed} onChange={e => updateClip(selectedClip.id, {speed: parseFloat(e.target.value)})} className="w-full h-1.5 bg-zinc-700 rounded-full accent-blue-500 appearance-none" />
                         </div>
                     )}
                     
                     {activeTab === 'audio' && selectedClip && (
                         <div className="space-y-4">
                             <div className="space-y-2">
                                 <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                                     <span>Volume</span>
                                     <span className="text-white font-bold">{(selectedClip.audio.volume * 100).toFixed(0)}%</span>
                                 </div>
                                 <input type="range" min="0" max="1" step="0.01" value={selectedClip.audio.volume} onChange={e => updateClip(selectedClip.id, { audio: { ...selectedClip.audio, volume: parseFloat(e.target.value) } })} className="w-full h-1.5 bg-zinc-700 rounded-full accent-blue-500 appearance-none" />
                             </div>
                             <div className="space-y-2">
                                  <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                                     <span>Fade In</span>
                                     <span className="text-white font-bold">{selectedClip.audio.fadeIn.toFixed(1)}s</span>
                                 </div>
                                 <input type="range" min="0" max="5" step="0.1" value={selectedClip.audio.fadeIn} onChange={e => updateClip(selectedClip.id, { audio: { ...selectedClip.audio, fadeIn: parseFloat(e.target.value) } })} className="w-full h-1.5 bg-zinc-700 rounded-full accent-green-500 appearance-none" />
                             </div>
                             <div className="space-y-2">
                                  <div className="flex justify-between text-[10px] font-mono text-zinc-500">
                                     <span>Fade Out</span>
                                     <span className="text-white font-bold">{selectedClip.audio.fadeOut.toFixed(1)}s</span>
                                 </div>
                                 <input type="range" min="0" max="5" step="0.1" value={selectedClip.audio.fadeOut} onChange={e => updateClip(selectedClip.id, { audio: { ...selectedClip.audio, fadeOut: parseFloat(e.target.value) } })} className="w-full h-1.5 bg-zinc-700 rounded-full accent-red-500 appearance-none" />
                             </div>
                         </div>
                     )}

                     {activeTab === 'filters' && selectedClip && (
                         <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
                             {['Normal', 'B&W', 'Vivid', 'Warm', 'Cool', 'Vintage'].map((f, i) => (
                                 <button key={f} onClick={() => updateClip(selectedClip.id, { filters: { ...selectedClip.filters, grayscale: i === 1 ? 100 : 0, saturate: i === 2 ? 150 : 100 } })} className="flex flex-col gap-2 min-w-[60px] items-center">
                                     <div className={`w-12 h-12 rounded-lg bg-zinc-800 border-2 ${i===0 ? 'border-white' : 'border-white/10'}`} style={{filter: i===1?'grayscale(100%)': i===2?'saturate(1.5)': ''}} />
                                     <span className="text-[9px] uppercase font-bold text-zinc-500">{f}</span>
                                 </button>
                             ))}
                         </div>
                     )}

                     {activeTab === 'format' && (
                         <div className="flex gap-4 justify-center pb-2">
                            {['9:16', '16:9', '1:1', '4:5'].map(ratio => (
                                 <button 
                                    key={ratio}
                                    onClick={() => setState(p => ({...p, canvasRatio: ratio}))}
                                    className={`px-4 py-2 rounded-lg font-bold text-xs transition-colors ${state.canvasRatio === ratio ? 'bg-blue-600 text-white' : 'bg-zinc-800 text-zinc-400 hover:text-white'}`}
                                 >
                                     {ratio}
                                 </button>
                            ))}
                         </div>
                     )}
                 </div>
             )}
         </div>

         {/* PLAYBACK BAR */}
         <div className="shrink-0 h-12 bg-black flex items-center justify-between px-4 border-t border-white/10 z-30">
             <div className="flex items-center gap-3">
                 <button onClick={() => setState(p => ({...p, isPlaying: !p.isPlaying}))} className="w-8 h-8 flex items-center justify-center bg-white rounded-full text-black active:scale-90 transition-transform">
                     {state.isPlaying ? <Pause size={14} fill="black" /> : <Play size={14} fill="black" className="ml-0.5" />}
                 </button>
                 <div className="font-mono text-[10px] space-x-1">
                     <span className="text-white font-bold">{state.currentTime.toFixed(1)}s</span>
                     <span className="text-zinc-600">/</span>
                     <span className="text-zinc-500">{state.duration.toFixed(1)}s</span>
                 </div>
             </div>
             
             <div className="flex items-center gap-3">
                <button 
                    onClick={deleteClip} 
                    disabled={!selectedClip} 
                    className={`w-8 h-8 flex items-center justify-center rounded-full transition-colors ${selectedClip ? 'bg-red-500/10 text-red-500 active:scale-90 hover:bg-red-500/20' : 'text-zinc-800'}`}
                >
                    <Trash2 size={16} />
                </button>
                <div className="w-px h-4 bg-white/10" />
                <button onClick={splitClip} disabled={!selectedClip} className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${selectedClip ? 'bg-zinc-800 border-white/20 text-white' : 'bg-transparent border-white/5 text-zinc-700'}`}>
                    <Scissors size={12} /> Split
                </button>
             </div>
         </div>

         {/* TIMELINE */}
         <div className="shrink-0 h-[35vh] bg-[#080808] border-t border-white/5 relative">
             <Timeline state={state} setState={setState} updateClip={updateClip} />
         </div>

         {/* TOOLBAR */}
         <Toolbar activeTab={activeTab} setActiveTab={setActiveTab} onAdd={t => {setPickerType(t); setShowAssetPicker(true)}} onAddText={() => setTextInput({show:true, value:''})} onSplit={splitClip} selectedClip={selectedClip} />
      </div>

      {/* OVERLAYS */}
      {textInput.show && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex flex-col justify-center px-8">
              <input ref={textInputRef} autoFocus value={textInput.value} onChange={e => setTextInput(p => ({...p, value: e.target.value}))} onKeyDown={e => e.key==='Enter' && handleAddText()} placeholder="MATN..." className="bg-transparent text-center text-3xl font-black text-white outline-none border-b-2 border-blue-600 pb-2 uppercase placeholder:text-zinc-800" />
              <div className="flex gap-4 mt-8">
                  <button onClick={() => setTextInput({show:false, value:''})} className="flex-1 py-4 bg-zinc-900 rounded-xl font-bold uppercase text-xs text-zinc-500">Bekor</button>
                  <button onClick={handleAddText} className="flex-1 py-4 bg-blue-600 rounded-xl font-bold uppercase text-xs text-white">Qo'shish</button>
              </div>
          </div>
      )}

      {showAssetPicker && <AssetPicker type={pickerType} onSelect={handleAddAsset} onClose={() => setShowAssetPicker(false)} />}
      {state.isMixerOpen && <MixerPanel state={state} onClose={() => setState(p => ({...p, isMixerOpen: false}))} updateClip={updateClip} />}
    </div>
  );
};

export default App;
